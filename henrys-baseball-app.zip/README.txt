HENRY'S BASEBALL BASH - iPad home screen app

Upload ALL of these files (not the zip itself) to a free web host, keeping them in the same folder:
  index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png, apple-touch-icon.png

Then on the iPad:
  1. Open the web address in Safari (while online).
  2. Wait for the game to appear, then tap Share > Add to Home Screen > Add.
  3. Open the game once from the new icon. After that it works with no internet.

Easy free host: GitHub Pages (Settings > Pages > Deploy from branch "main", folder "/ (root)").
